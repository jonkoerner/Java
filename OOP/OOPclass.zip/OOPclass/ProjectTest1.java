public class ProjectTest1{
    public static void main(String[] args){
        Project codeProject = new Project("Coder", "this is my elavator speech");
        // String projectName = codeproject.getName();
        System.out.println(codeProject.elavatorPitch()+" "+ codeProject.getName());
    }
}
