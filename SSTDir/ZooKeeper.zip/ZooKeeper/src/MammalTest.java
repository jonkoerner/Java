
public class MammalTest {

	public static void main(String[] args) {
		Mammal h= new Mammal();
		h.displayenergy();
		Gorilla g= new Gorilla();
		g.throwSomething();
		g.throwSomething();
		g.throwSomething();
		g.displayenergy();
		g.eatBananas();
		g.eatBananas();
		g.displayenergy();
		g.climb();
		g.displayenergy();
	}
}
