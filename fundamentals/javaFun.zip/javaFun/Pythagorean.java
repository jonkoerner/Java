public class Pythagorean {
        public static void main(String[] args) {
            CalculateHypotenuse ofNew = new CalculateHypotenuse();
            double result = ofNew.calculate(2,4);
            System.out.println(result);
    } 
} 